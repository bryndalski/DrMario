const gameLevelsSettings = [
    levelZeroX = {
        virusNumber: 1
    },
    levelZero = {
        virusNumber: 4
    },
    levelOne = {
        virusNumber: 8
    },
    levelTwo = {
        virusNumber: 12
    },
    levelThree = {
        virusNumber: 16
    },
    levelFour = {
        virusNumber: 20
    },
    levelFive = {
        virusNumber: 24
    },
    levelSix = {
        virusNumber: 28
    },
    levelSeven = {
        virusNumber: 32
    },
    levelEight = {
        virusNumber: 36
    },
    levelNine = {
        virusNumber: 40
    },
    levelTen = {
        virusNumber: 44
    },
    levelEleven = {
        virusNumber: 48
    },
    levelTwelve = {
        virusNumber: 52
    },
    levelThirteen = {
        virusNumber: 56
    },
    levelFourteen = {
        virusNumber: 60
    },
    levelFiveteen = {
        virusNumber: 64
    },
    levelSixteen = {
        virusNumber: 68
    },
    levelSeventeen = {
        virusNumber: 72
    },
    levelEighteen = {
        virusNumber: 76
    },
    levelNineteen = {
        virusNumber: 80
    },
    levelTwenty = {
        virusNumber: 84
    },

]